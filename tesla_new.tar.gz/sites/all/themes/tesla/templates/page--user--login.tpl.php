<div id="user-login">
<?php print render($page['content']); ?>
</div>